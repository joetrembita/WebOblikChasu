
window.__APP_CONFIG__ = {
  API_BASE_URL: "https://brakedown.up.railway.app"
};
